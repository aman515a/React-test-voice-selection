
import React from "react";
import {
    Typography,
    Button,
    Box
} from "@mui/material";
import RestartAltIcon from "@mui/icons-material/RestartAlt";

interface ResetProps {
    onReset(): void
}

function Reset(props: ResetProps) {
    return (
        <Box
            sx={{
                flexDirection: "row",
                justifyContent: "space-between",
                display: "flex",
                marginTop: 2
            }}
        >
            <Typography color={'#444444'}>Filter</Typography>
            <Button variant='contained' startIcon={<RestartAltIcon />} onClick={props.onReset}>
                Reset
            </Button>
        </Box>
    )
}

export default Reset;