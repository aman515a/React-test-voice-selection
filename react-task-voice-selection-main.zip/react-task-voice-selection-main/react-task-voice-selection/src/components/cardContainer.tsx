import React, { useRef, useState, useEffect } from "react";
import { Typography, Box, IconButton, Grid, Card, Chip } from "@mui/material";
import PlayCircleRoundedIcon from "@mui/icons-material/PlayCircleRounded";
import ReactAudioPlayer from "react-audio-player";

interface CardProps {
  language?: string | undefined;
  gender?: string | undefined;
  items: Array<any>;
}

function CardContainer(props: CardProps) {
  const playerRef = useRef<any>(null);
  const [file, setFile] = useState("");
  let array = [...props.items];

  if (props.gender) {
    array = [...array].filter(
      (item) => item.gender.toLowerCase() === props.gender?.toLowerCase()
    );
  }
  if (props.language) {
    array = [...array].filter(
      (item) =>
        item.languageCode.toLowerCase() === props.language?.toLowerCase()
    );
  }
  useEffect(() => {
    if (playerRef && playerRef.current && file) {
      playerRef.current.audioEl.current.play();
    }
  }, [file]);

  return (
    <Box sx={{ p: 10 }}>
      <Grid
        container
        spacing={{ xs: 2, md: 2 }}
        columns={{ xs: 2, sm: 6, md: 8 }}
      >
        {array.map((lang: any, index: number) => (
          <Grid
            item
            xs={2}
            sm={4}
            md={4}
            key={index}
            sx={{ marginBottom: "30px" }}
          >
            <Card
              sx={{
                minHeight: "180px",
                padding: "10px",
                boxShadow: "none",
                border: "0.2px solid rgba(128,128,128,0.3)",
                borderRadius: "30px"
              }}
            >
              <Box
                sx={{
                  flexDirection: "row",
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <Box
                  sx={{
                    flexDirection: "row",
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <img
                    alt={lang.countryCode}
                    className="flag"
                    src={lang.image}
                  />
                  <Typography variant="h6" sx={{ marginLeft: 2 }}>
                    {lang.name}
                  </Typography>
                </Box>
                <IconButton
                  aria-label="player"
                  onClick={() => {
                    setFile(lang.audio);
                  }}
                >
                  <PlayCircleRoundedIcon
                    sx={{ fontSize: "50px", color: "#7358f3" }}
                    color={"primary"}
                  />
                </IconButton>
              </Box>
              <Box
                sx={{
                  flexDirection: "row",
                  display: "flex",
                  alignItems: "left",
                  // justifyContent: "space-between",
                  px: 1,
                  mt: 2,
                }}
              >
                <Chip
                  sx={{ mr: 1, background: "rgba(128, 128, 128, 0.05)" }}
                  label={lang.gender}
                />
                <Chip
                  sx={{ mr: 1, background: "rgba(128, 128, 128, 0.05)" }}
                  label={lang.language}
                />
                <Chip
                  sx={{ mr: 1, background: "rgba(128, 128, 128, 0.05)" }}
                  label={lang.languageCode}
                />
                <Chip
                  sx={{ mr: 1, background: "rgba(128, 128, 128, 0.05)" }}
                  label={lang.type}
                />
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>
      {file && (
        <Box sx={{ marginTop: 5 }}>
          <ReactAudioPlayer
            ref={playerRef}
            src={file}
            autoPlay={false}
            controls
            onEnded={() => {
              setFile("");
            }}
          />
        </Box>
      )}
    </Box>
  );
}

export default CardContainer;
