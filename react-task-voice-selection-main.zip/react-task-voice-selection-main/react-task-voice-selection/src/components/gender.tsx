
import React from "react";
import {
  Box,
  IconButton,
  Typography
} from "@mui/material";
import FemaleIcon from "@mui/icons-material/Female";
import MaleIcon from "@mui/icons-material/Male";
import TransgenderIcon from "@mui/icons-material/Transgender";
interface GenderProps {
  onGenderSelect(item: string): void
}

function Gender(props: GenderProps) {
  return (
    <Box
      sx={{
        flexDirection: "row",
        justifyContent: "space-between",
        display: "flex",
        borderTop: 1,
        borderBottom: 1,
        py: 1,
        my: 1,
        borderBottomColor: '#dddddd',
        borderTopColor: '#dddddd'
      }}
    >
      <Typography color='#444444'>Gender</Typography>
      <Box>
        <IconButton aria-label="male" onClick={() => {
          props.onGenderSelect('male');
        }}>
          <MaleIcon />
        </IconButton>
        <IconButton aria-label="female" onClick={() => {
          props.onGenderSelect('female');
        }}>
          <FemaleIcon />
        </IconButton>
        <IconButton aria-label="trans" onClick={() => {
          props.onGenderSelect('trans');
        }}>
          <TransgenderIcon />
        </IconButton>
      </Box>
    </Box>
  )
}

export default Gender;