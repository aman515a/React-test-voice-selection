import React, { useState } from "react";
import { Box, FormLabel, FormControlLabel, Checkbox } from "@mui/material";
import RadioGroupFormsy from "formsy-react";

interface AgeProps {
  onAgeSelect(item: any): void
}


function Age(props: AgeProps) {
  const [arrayAge, setArrayAge] = useState([
    { id: 1, label: "Child", checked: false },
    { id: 2, label: "Youth", checked: false },
    { id: 3, label: "Middle-Aged", checked: false },
    { id: 4, label: "Older", checked: false },
  ]);

  const handleChange = (index: number) => {
    const array = [...arrayAge].map((age) => {
      return {
        ...age,
        checked: false,
      };
    });
    array[index].checked = !array[index].checked;
    setArrayAge(array);
    if (array[index].checked) {
      props.onAgeSelect(array[index]);
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        borderBottom: 1,
        my: 1,
        borderBottomColor: "#dddddd",
      }}
    >
      <FormLabel sx={{ width: "100%", textAlign: "left", color: '#444444' }} component="legend">
        Age
      </FormLabel>
      <RadioGroupFormsy className="my-8" name="Language">
        {arrayAge.map((age, index) => (
          <FormControlLabel key={age.id}
            componentsProps={{ typography: { color: "#bbbbbb" } }}
            value={age.label}
            control={
              <Checkbox
                checked={age.checked}
                color="primary"
                onChange={() => {
                  handleChange(index);
                }}
              />
            }
            label={age.label}
          />
        ))}
      </RadioGroupFormsy>
    </Box>
  );
}

export default Age;
