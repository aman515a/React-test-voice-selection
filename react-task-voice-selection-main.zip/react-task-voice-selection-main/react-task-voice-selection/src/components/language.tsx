
import React, { useState } from "react";
import {
  Box,
  FormLabel,
  FormControlLabel,
  Radio
} from "@mui/material";
import RadioGroupFormsy from "formsy-react";

interface LanguageProps {
  onSelection(item: any): void,
  items: Array<any>;
}

function Language(props: LanguageProps) {
  // const getLanguages = () => {
  //   const languages: Array<any> = [];
  
  //   props.items.forEach((item) => {
  //     let ind = languages.findIndex((l) => l.code === item.languageCode);
  //     if (ind === -1) {
  //       languages.push({
  //         code: item.languageCode,
  //         name: item.language,
  //         nativeName: item.language,
  //       });
  //     }
  //   });
  //   return languages;
  // };

  const arrayLanguages = [
  { "code": "en", "name": "English", "nativeName": "English" },
  { "code": "pt", "name": "Portugese", "nativeName": "Portugese" },
  { "code": "af", "name": "Afrikaans", "nativeName": "Afrikaans" },
  { "code": "ak", "name": "Akan", "nativeName": "Akan" },
  { "code": "sq", "name": "Albanian", "nativeName": "Shqip" },
  { "code": "am", "name": "Amharic", "nativeName": "አማርኛ" },
  { "code": "ar", "name": "Arabic", "nativeName": "العربية" },
  { "code": "an", "name": "Aragonese", "nativeName": "Aragonés" },
  { "code": "hy", "name": "Armenian", "nativeName": "Հայերեն" },
  { "code": "as", "name": "Assamese", "nativeName": "অসমীয়া" },
  { "code": "ae", "name": "Avestan", "nativeName": "avesta" },
  { "code": "ay", "name": "Aymara", "nativeName": "aymar aru" },
  { "code": "az", "name": "Azerbaijani", "nativeName": "azərbaycan dili" },
  { "code": "bm", "name": "Bambara", "nativeName": "bamanankan" },
  { "code": "ba", "name": "Bashkir", "nativeName": "башҡорт теле" },
  { "code": "eu", "name": "Basque", "nativeName": "euskara, euskera" },
  { "code": "be", "name": "Belarusian", "nativeName": "Беларуская" },
  { "code": "bn", "name": "Bengali", "nativeName": "বাংলা" },
  { "code": "bh", "name": "Bihari", "nativeName": "भोजपुरी" },
  { "code": "bi", "name": "Bislama", "nativeName": "Bislama" },
  { "code": "bs", "name": "Bosnian", "nativeName": "bosanski jezik" },
  { "code": "br", "name": "Breton", "nativeName": "brezhoneg" },
  { "code": "bg", "name": "Bulgarian", "nativeName": "български език" },
  { "code": "my", "name": "Burmese", "nativeName": "ဗမာစာ" },
  { "code": "ch", "name": "Chamorro", "nativeName": "Chamoru" },
  { "code": "ce", "name": "Chechen", "nativeName": "нохчийн мотт" },
  { "code": "zh", "name": "Chinese", "nativeName": "中文 (Zhōngwén), 汉语, 漢語" },
  { "code": "cv", "name": "Chuvash", "nativeName": "чӑваш чӗлхи" },
  { "code": "kw", "name": "Cornish", "nativeName": "Kernewek" },
  { "code": "co", "name": "Corsican", "nativeName": "corsu, lingua corsa" },
  { "code": "cr", "name": "Cree", "nativeName": "ᓀᐦᐃᔭᐍᐏᐣ" },
  { "code": "eo", "name": "Esperanto", "nativeName": "Esperanto" },
  { "code": "et", "name": "Estonian", "nativeName": "eesti, eesti keel" },
  { "code": "ee", "name": "Ewe", "nativeName": "Eʋegbe" },
  { "code": "fo", "name": "Faroese", "nativeName": "føroyskt" },
  { "code": "fj", "name": "Fijian", "nativeName": "vosa Vakaviti" },
 ]
  const [selectedLanguage, setSelectedLanguage] = useState({ code: '' });

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      <FormLabel sx={{ width: '100%', textAlign: 'left', color: '#444444' }} component="legend">Language</FormLabel>
      <RadioGroupFormsy
        className="my-8"
        name="Language"
      >
        {
          arrayLanguages.map((lang, index) => <FormControlLabel key = {lang.code}
            value={lang.name}
            componentsProps={{ typography: { color: '#bbbbbb' } }}
            control={<Radio checked={selectedLanguage.code === lang.code} color="primary" onChange={(e) => {
              if (e.target.checked) {
                setSelectedLanguage(arrayLanguages[index]);
                props.onSelection(arrayLanguages[index])
              } else {
                setSelectedLanguage({ code: '' });
              }
            }} />}
            label={lang.name}
          />)
        }
      </RadioGroupFormsy>
    </Box>
  )
}

export default Language;