import React, { useState } from "react";
import {
  Stack,
  Container,
  Box
} from "@mui/material";

import CardContainer from './components/cardContainer';
import Age from './components/age';
import Gender from './components/gender';
import Language from './components/language';
import Reset from './components/reset';

import "./App.css";

function App() {
  const [gender, setGender] = useState<string>('');
  const [language, setLanguage] = useState();
  const items: Array<any> = [
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ea",
      "name": "Brian",
      "gender": "Male",
      "language": "English",
      "languageCode": "en",
      "countryCode": "GB",
      "type": "Neural",
      image : require('./assets/images/gb.png'),
      'audio':'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/en-GB_Brian_Male_Standard.mp3?alt=media&token=1e3e6a6b-ecd0-483f-bef5-59c231977041'
    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269eb",
      "name": "Celine",
      "gender": "Female",
      "language": "French",
      "languageCode": "fr",
      "countryCode": "FR",
      "type": "Standard",
      image : require('./assets/images/fr.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/fr-FR_Celine_Female_Standard.mp3?alt=media&token=d0516d47-1a09-4565-870d-dd185a970f6a'
    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ec",
      "name": "Aditi",
      "gender": "Female",
      "language": "English",
      "languageCode": "en",
      "countryCode": "IN",
      "type": "Standard",
      image : require('./assets/images/in.png'),
      'audio':'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/en-IN_Aditi_Female_Standard.mp3?alt=media&token=14c346ae-8ba9-4f26-ad72-6093a6d8756a'

    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ed",
      "name": "Justin",
      "gender": "Male",
      "isChild": true,
      "language": "English",
      "languageCode": "en",
      "countryCode": "US",
      "type": "Neural",
      image : require('./assets/images/au.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/en-US_Justin_Male-child_Neural.mp3?alt=media&token=b5a345b4-2776-4305-a97e-4a06543b2184'

    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ee",
      "name": "Seoyeon",
      "gender": "Female",
      "language": "Korean",
      "languageCode": "ko",
      "countryCode": "KR",
      "type": "Standard",
      image : require('./assets/images/kr.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/ko-KR_Seoyeon_Female_Standard.mp3?alt=media&token=e7f87950-5ee1-4181-aa2e-a046d6079e7e'

    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ef",
      "name": "Ivy",
      "gender": "Female",
      "isChild": true,
      "language": "English",
      "languageCode": "en",
      "countryCode": "US",
      "type": "Neural",
      image : require('./assets/images/au.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/en-US_Ivy_Female-child_Neural.mp3?alt=media&token=340a518a-1188-41b8-b38d-d0808fa2e23f'

    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269aa",
      "name": "Cristiano",
      "gender": "Male",
      "language": "Portuguese",
      "languageCode": "pt",
      "countryCode": "PT",
      "type": "Standard",
      image : require('./assets/images/pt.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/pt-PT_Cristiano_Male_Standard.mp3?alt=media&token=d9389077-30c1-41f2-b80a-ed34458733c1'

    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ab",
      "name": "Vitoria",
      "gender": "Female",
      "language": "Portuguese",
      "languageCode": "pt",
      "countryCode": "BR",
      "type": "Standard",
      image : require('./assets/images/br.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/pt-BR_Vitoria_Female_Standard.mp3?alt=media&token=267939c3-fbfc-47a2-b385-8ce07e80655f'

    },
    {
      "id": "0017ec82-511d-4c3a-9a16-27343aa269ac",
      "name": "Vitoria",
      "gender": "Female",
      "language": "Portuguese",
      "languageCode": "pt",
      "countryCode": "BR",
      "type": "Neural",
      image : require('./assets/images/br.png'),
      audio:'https://firebasestorage.googleapis.com/v0/b/react-demo-d1551.appspot.com/o/pt-BR_Vitoria_Female_Neural.mp3?alt=media&token=1215a93a-4aef-47da-94ad-c6474181d7d1'

    }
  ]
  return (
    <Stack className="App">
      <Box
        sx={{
          flexDirection: "row",
          display: "flex",
        }}
      >
        <Box
          sx={{
            flexDirection: "column",
            display: "flex",
            backgroundColor: "#FBFAFE",
            maxHeight: "80vh",
            padding: "40px",
          }}
        >
          <Reset
            onReset={() => {
              setGender("");
              setLanguage(undefined);
            }}
          />
          <Gender
            onGenderSelect={(item) => {
              setGender(item);
            }}
          />
          <Age onAgeSelect={() => {}} />
          <Language
            onSelection={(item) => setLanguage(item.code)}
            items={items}
          />
        </Box>
        <CardContainer items={items} gender={gender} language={language} />
      </Box>
    </Stack>
  );
}

export default App;
